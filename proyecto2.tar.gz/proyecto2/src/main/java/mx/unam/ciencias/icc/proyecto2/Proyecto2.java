package mx.unam.ciencias.icc.proyecto2;

/**
 * Proyecto 2. 
 */
 public class Proyecto2 extends Application {

     public static void main(String[] args) {
	 /* Inicia la aplicación. */
	 launch(args);
     }
     
 }
