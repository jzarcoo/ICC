package mx.unam.ciencias.icc;

import mx.unam.ciencias.icc.igu.Aplicacion;

/**
 * Cliente proyecto 3.
 */
public class ClienteProyecto3 extends Aplicacion {

    public static void main(String[] args) {
        /* Todo se delega a la clase Aplicacion. */
        launch(args);
    }
}
